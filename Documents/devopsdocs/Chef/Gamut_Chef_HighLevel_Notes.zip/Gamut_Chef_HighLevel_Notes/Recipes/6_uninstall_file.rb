file 'reboot.log' do
  content "system has been rebooted!"
  action :delete
end

