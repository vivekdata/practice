file 'deployment.txt' do
  content "deployment is succussful!\n"
  mode '777'
  owner 'web'
  group 'web'
end
